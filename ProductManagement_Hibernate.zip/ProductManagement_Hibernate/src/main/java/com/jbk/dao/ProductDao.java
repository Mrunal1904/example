package com.jbk.dao;




import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.QueryException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.jbk.config.HibernateConfig;
import com.jbk.entity.Product;



public class ProductDao {
	
	public String saveProduct(Product product) {
		SessionFactory sessionFactory = HibernateConfig.getSessionFactory();
		boolean isAdded =false;
		String msg="";
		try {
			Session session =sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
		   session.save(product);
		   transaction.commit();
		   isAdded=true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(isAdded) {
			msg="Saved !!";
		}
		else {
			msg="not Saved!!";
		}
		
		return msg;
		
	}
	
	public Product getProductName(int id) {
		SessionFactory sessionFactory = HibernateConfig.getSessionFactory();
		Product product=null;
		try {
			Session session=sessionFactory.openSession();
			product =session.get(Product.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return product;
		
	}
	
	public String updateProduct(Product product) {
		
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		String msg=null;
		try {
			Session session =sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			     
			Product prd=session.get(Product.class, product.getProductId());
			session.evict(prd);
			if (prd!=null)
			{             
				session.update(product);
			    transaction.commit();
			    msg="UPDATED !!";
			}
			else
			{
				msg="PRODUCT NOT EXISTS FOR UPDATE ID"+product.getProductId();
			}
		 
		    } catch (Exception e) {
			e.printStackTrace();
		}
		return msg;
		
		
	}
	
	public String deleteProductById(int ProductId) {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		String msg=null;
		try {
			Session session =sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Product product=session.get(Product.class, ProductId);
			
			if(product!=null) {
				session.delete(product);
				transaction.commit();
				msg="DELETED";
			}
			else
			{
				msg="PRODUCT NOT EXISTS FOR DELETE ID"+ProductId;
			}
		
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return msg ;
		
		
	}
	
	public java.util.List<Product> listOfProduct() {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		java.util.List<Product> list = null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			
			 list = criteria.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public java.util.List<Product> listOfProductByOrder(String sortBy,String OrderBy) {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		java.util.List<Product> list = null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			
			if ("asc".equalsIgnoreCase(OrderBy)) {
				criteria.addOrder(Order.asc(sortBy));
			} else if ("desc".equalsIgnoreCase(OrderBy)) {
					criteria.addOrder(Order.desc(sortBy));
			}else {
				System.out.println("invalid order");
			}
			 
			list=criteria.list();
		}catch (QueryException e) {
			System.out.println("could not resolve property  "+sortBy+" in product");
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public java.util.List<Product> pagination(int maxRecord) {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		java.util.List<Product> list = null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			
			criteria.setFirstResult(0);
			criteria.setMaxResults(maxRecord);
			 
			list=criteria.list();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
		
	}
	
	public Product GetProductByName(String productName) {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		Product product=null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			criteria.add(Restrictions.eq("productName", productName));
             product=(Product) criteria.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return product;
		
	}
	public List<Product> GetProductByExpression(String expression) {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		List<Product> productlist=null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			criteria.add(Restrictions.like("productName","%"+expression+"%"));
             productlist= criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return productlist;
		
	}
	public double projectionExForSum() {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		double sum=0;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			criteria.setProjection(Projections.sum("productPrice"));
			List<Double> list=criteria.list();
			sum=list.get(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sum;
		
	}
	public double projectionExForMinValue() {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		double min=0;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			criteria.setProjection(Projections.min("productPrice"));
			List<Double> list=criteria.list();
			min=list.get(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return min;
		
	}
	public double projectionExForMaxValue() {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		double max=0;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			criteria.setProjection(Projections.max("productPrice"));
			List<Double> list=criteria.list();
			max=list.get(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return max;
		
	}
	@SuppressWarnings("unused")
	public long projectionExForRowCount() {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		Session session =sessionFactory.openSession();
		long rowC=0;
		try {
			
			Criteria criteria=session.createCriteria(Product.class);
			criteria.setProjection(Projections.rowCount());
			 
		List list = criteria.list();
		 rowC = (Long) list.get(0);

		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		}
		return rowC  ;
		
	}
	
	
	
	

	public List<Product> getProductWithGivenPrice(double productPrice) {
		
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		List<Product> productlist=null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			Scanner scanner = new Scanner(System.in);
			int choice;
			char ch = 0;
			do {
			System.out.println("press 1 for product price equals");
			System.out.println("press 2 for product price greaterthan");
			System.out.println("press 3 for product price greater than or equal to");
			System.out.println("press 4 for product price less than");
			System.out.println("press 5 for product price less than or equal to");
			
			
			choice=scanner.nextInt();
			switch (choice ) {
			case 1:
			{
				criteria.add(Restrictions.eq("productPrice", productPrice));
				productlist=criteria.list();
				break;
			}
			case 2:
			{
				criteria.add(Restrictions.gt("productPrice", productPrice));
				productlist=criteria.list();
				break;
			}
			case 3:
			{
				criteria.add(Restrictions.ge("productPrice", productPrice));
				productlist=criteria.list();
				break;
			}
			case 4:
			{
				criteria.add(Restrictions.lt("productPrice", productPrice));
				productlist=criteria.list();
				break;
			}
			case 5:
			{
				criteria.add(Restrictions.lt("productPrice", productPrice));
				productlist=criteria.list();
				break;
			}
			
			}
			
		}while (ch=='y' || ch=='Y');
			System.out.println("terminate");
		}catch (Exception e) {
			e.printStackTrace();
		}
		return productlist;
		}
	
	
	public List<Product> betweenRange(double p1,double p2) {
		SessionFactory sessionFactory=HibernateConfig.getSessionFactory();
		List<Product> productlist=null;
		try {
			Session session =sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Product.class);
			criteria.add(Restrictions.between("productPrice", p1, p2));
			productlist=criteria.list();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return productlist;		
	}
	
}


  



	
	
	
	
	
	
	
	
		
		
		



