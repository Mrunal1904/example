package com.jbk;

import java.util.List;
import java.util.Scanner;

import com.jbk.config.HibernateConfig;
import com.jbk.dao.ProductDao;
import com.jbk.entity.Product;
import com.jbk.utility.ProductUtility;

public class TestProduct {
	public static void main(String[] args) {
		//save product info db
		ProductDao dao = new ProductDao();
		Scanner scanner = new Scanner(System.in);
		int choice;
		char ch;
		do {
			System.out.println("press 1 to save");
			System.out.println("press 2 to get product by id");
			System.out.println("press 3 to update");
			System.out.println("press 4 to delete");
			System.out.println("press 5 for list");
			System.out.println("press 6 for list in order");
			System.out.println("press 7 for pagination");
			System.out.println("press 8 to get product by ProductName using Restriction");
			System.out.println("press 9 to get product by characters using Restriction");
			System.out.println("press 10 for projection");
			System.out.println("press 11 to get product by given price");
			System.out.println("press 12 for product price between range");
			System.out.println("press 13 for projectionEx For Min Value");
			System.out.println("press 14 for projectionEx For Min Value");
			System.out.println("press 15 for projectionEx For RowCount");

			choice=scanner.nextInt();
			
			switch (choice ) {
			case 1:
			{	
				Product product = ProductUtility.getProductFromUser();
				String msg=dao.saveProduct(product);
				
				System.out.println(msg);
				break;
			}
			case 2:
			{
				System.out.println("Enter productId");
				int id=scanner.nextInt();
				Product product=dao.getProductName(id);
				if(product!=null) {
					System.out.println(product);
					}
				else
					System.out.println("PRODUCT NOT FOUND EITH ID :"+id);
				
			    break;
			}
			case 3:
			{
				Product product=ProductUtility.getProductFromUser();
				String msg = dao.updateProduct(product);
				System.out.println(product);
				System.out.println(msg);
				break;
			}
			case 4:
			{
				System.out.println("Enter Product id");
				int id =scanner.nextInt();
				
				String msg = dao.deleteProductById(id);
				System.out.println(msg);
				break;
				
			}
			case 5:
			{
				List<Product> list = dao.listOfProduct();
				for (Product product : list) {
					System.out.println(product);
				}
				break;
			}
			case 6:
			{ 
				System.out.println("enter Sorted by");
				String sortby=scanner.next();
				System.out.println("enter order by ASC/DESC");
				String orderby=scanner.next();
				
				List<Product> listOfProductByOrder = dao.listOfProductByOrder(sortby, orderby);
				for ( Product product : listOfProductByOrder) {
					System.out.println(product);
				}
				break;
			}
			case 7:
			{
				System.out.println("no. of record to be viewed");
				int record=scanner.nextInt();
				List<Product> list = dao.pagination(record);
				for (Product product : list) {
					System.out.println(product);
				}
				break;
			}
			case 8:
			{
				System.out.println("enter product name");
				String productName=scanner.next();
				Product product = dao.GetProductByName(productName);
				if (product!=null) {
					System.out.println(product);
				}else {
					System.out.println("product not exists with Name :"+ productName);
				}
				
				
				break;
			}
			case 9:
			{
				System.out.println("enter character for ProductName");
				String expression=scanner.next();
				List<Product> productList= dao.GetProductByExpression(expression);
			
					System.out.println(productList);
				
				break;
			}
			case 10:
			{
				double sum = dao.projectionExForSum();
				System.out.println(sum);
				break;
			
			}
			case 11:
			{
				System.out.println("enter product price");
				double price =scanner.nextDouble();
				List<Product> list=dao.getProductWithGivenPrice(price);
				System.out.println(list);
				
				break;
			
			}
			case 12:
			{
				System.out.println("enter product price1");
				double price1 =scanner.nextDouble();
				System.out.println("enter product price2");
				double price2 =scanner.nextDouble();
				List<Product> list=dao.betweenRange(price1, price2);
				System.out.println(list);
				
				break;
			}
			case 13:
			{
				double min = dao.projectionExForMinValue();
				System.out.println(min);
				break;
			
			}
			case 14:
			{
				double max = dao.projectionExForMaxValue();
				System.out.println(max);
				break;
			
			}
			case 15:
			{
				long rowcount = dao.projectionExForRowCount();
				System.out.println(rowcount);
				break;
			
			}
			
			
			
				
			default:
				System.out.println("invalid choice !!");
				break;
			}
			System.out.println("do you want to continue y/n !! ");
			ch=scanner.next().charAt(0);
		} while (ch=='y' || ch=='Y');
		System.out.println("terminate");
	}
}
