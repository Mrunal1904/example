package com.jbk.utility;

import java.util.Scanner;

import com.jbk.entity.Product;

public class ProductUtility {
		
	public static Product getProductFromUser() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter id");
		int id =scanner.nextInt();
	
		System.out.println("enter ProductName");
		String ProductName = scanner.next();
		
		System.out.println("Enter ProductPrice");
		double ProductPrice = scanner.nextDouble();
		
		System.out.println("Enter ProductQuantity");
		int ProductQuantity = scanner.nextInt();
		
		System.out.println("Enter ProductCatergory");
		String ProductCatergory = scanner.next();
		
		Product product = new Product(id, ProductName, ProductPrice, ProductQuantity, ProductCatergory);
		return product;
	
}
}
